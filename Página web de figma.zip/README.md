
  # Página web de comercio electrónico

  This is a code bundle for Página web de comercio electrónico. The original project is available at https://www.figma.com/design/mVtUS9pPnhrUYcJfIXCy0v/P%C3%A1gina-web-de-comercio-electr%C3%B3nico.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  