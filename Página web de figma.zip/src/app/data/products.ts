export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  category: string;
  image: string;
  rating: number;
  inStock: boolean;
  featured?: boolean;
  discount?: number;
}

export const products: Product[] = [
  // Patines en Línea Urbanos
  {
    id: "1",
    name: "Patines Urbanos Speed Line Pro",
    description: "Patines de alta velocidad con rodamientos ABEC-9 para ciudad",
    price: 189.99,
    originalPrice: 249.99,
    category: "urban",
    image: "https://images.unsplash.com/photo-1663760900588-a0fdcfa71469?w=400",
    rating: 4.8,
    inStock: true,
    featured: true,
    discount: 24
  },
  {
    id: "2",
    name: "Patines CityGlide Comfort",
    description: "Máximo confort para desplazamientos diarios urbanos",
    price: 129.99,
    category: "urban",
    image: "https://images.unsplash.com/photo-1773034475403-58d0f5c2b997?w=400",
    rating: 4.6,
    inStock: true,
    featured: true
  },
  {
    id: "3",
    name: "Patines Urban Explorer",
    description: "Diseño ergonómico para largas distancias en asfalto",
    price: 149.99,
    category: "urban",
    image: "https://images.unsplash.com/photo-1771351521522-49df2a082dfc?w=400",
    rating: 4.7,
    inStock: true,
    featured: false
  },
  
  // Patines en Línea Fitness
  {
    id: "4",
    name: "Patines Fitness FlexFit Pro",
    description: "Perfectos para entrenamientos y ejercicio cardiovascular",
    price: 159.99,
    originalPrice: 199.99,
    category: "fitness",
    image: "https://images.unsplash.com/photo-1663760900588-a0fdcfa71469?w=400",
    rating: 4.9,
    inStock: true,
    featured: true,
    discount: 20
  },
  {
    id: "5",
    name: "Patines Marathon Elite",
    description: "Para entrenamientos intensivos y largas distancias",
    price: 179.99,
    category: "fitness",
    image: "https://images.unsplash.com/photo-1773034475403-58d0f5c2b997?w=400",
    rating: 4.7,
    inStock: true,
    featured: true
  },
  {
    id: "6",
    name: "Patines Training Plus",
    description: "Soporte y estabilidad para sesiones de entrenamiento",
    price: 139.99,
    category: "fitness",
    image: "https://images.unsplash.com/photo-1771351521522-49df2a082dfc?w=400",
    rating: 4.5,
    inStock: true,
    featured: false
  },
  
  // Patines en Línea Velocidad/Carreras
  {
    id: "7",
    name: "Patines Speed Racer X1",
    description: "Diseño aerodinámico para máxima velocidad",
    price: 249.99,
    category: "speed",
    image: "https://images.unsplash.com/photo-1663760900588-a0fdcfa71469?w=400",
    rating: 4.9,
    inStock: true,
    featured: false
  },
  {
    id: "8",
    name: "Patines Competition Pro",
    description: "Para competiciones y carreras profesionales",
    price: 299.99,
    originalPrice: 399.99,
    category: "speed",
    image: "https://images.unsplash.com/photo-1773034475403-58d0f5c2b997?w=400",
    rating: 5.0,
    inStock: true,
    featured: true,
    discount: 25
  },
  {
    id: "9",
    name: "Patines Velocity Carbon",
    description: "Construcción en fibra de carbono ultraligera",
    price: 349.99,
    category: "speed",
    image: "https://images.unsplash.com/photo-1771351521522-49df2a082dfc?w=400",
    rating: 4.8,
    inStock: false,
    featured: false
  },
  
  // Patines en Línea Principiantes
  {
    id: "10",
    name: "Patines Starter Basic",
    description: "Perfectos para comenzar en el mundo del patinaje",
    price: 79.99,
    category: "beginner",
    image: "https://images.unsplash.com/photo-1663760900588-a0fdcfa71469?w=400",
    rating: 4.4,
    inStock: true,
    featured: true
  },
  {
    id: "11",
    name: "Patines Easy Learn",
    description: "Estabilidad y seguridad para principiantes",
    price: 89.99,
    originalPrice: 109.99,
    category: "beginner",
    image: "https://images.unsplash.com/photo-1773034475403-58d0f5c2b997?w=400",
    rating: 4.5,
    inStock: true,
    featured: false,
    discount: 18
  },
  {
    id: "12",
    name: "Patines Junior First",
    description: "Diseño ajustable para jóvenes patinadores",
    price: 69.99,
    category: "beginner",
    image: "https://images.unsplash.com/photo-1771351521522-49df2a082dfc?w=400",
    rating: 4.6,
    inStock: true,
    featured: false
  }
];

export const categories = [
  {
    id: "urban",
    name: "Patines Urbanos",
    description: "Para desplazamiento y ciudad",
    icon: "Navigation",
    image: "https://images.unsplash.com/photo-1771351521522-49df2a082dfc?w=600"
  },
  {
    id: "fitness",
    name: "Patines Fitness",
    description: "Entrenamiento y ejercicio",
    icon: "Activity",
    image: "https://images.unsplash.com/photo-1663760900588-a0fdcfa71469?w=600"
  },
  {
    id: "speed",
    name: "Patines Velocidad",
    description: "Competición y carreras",
    icon: "Zap",
    image: "https://images.unsplash.com/photo-1773034475403-58d0f5c2b997?w=600"
  },
  {
    id: "beginner",
    name: "Patines Principiantes",
    description: "Para empezar a patinar",
    icon: "Heart",
    image: "https://images.unsplash.com/photo-1756888821859-64e8618cc1e6?w=600"
  }
];

export const reviews = [
  {
    id: "1",
    name: "Carlos Martínez",
    rating: 5,
    comment: "Los mejores patines en línea que he probado. La calidad es increíble y son súper cómodos.",
    date: "2026-03-20",
    product: "Patines Urbanos Speed Line Pro"
  },
  {
    id: "2",
    name: "Ana García",
    rating: 5,
    comment: "Perfectos para mis entrenamientos diarios. Me encanta la velocidad que alcanzo con ellos.",
    date: "2026-03-18",
    product: "Patines Fitness FlexFit Pro"
  },
  {
    id: "3",
    name: "Miguel Rodríguez",
    rating: 4,
    comment: "Excelente relación calidad-precio. Ideales para moverse por la ciudad.",
    date: "2026-03-15",
    product: "Patines CityGlide Comfort"
  },
  {
    id: "4",
    name: "Laura Fernández",
    rating: 5,
    comment: "Calidad premium y durabilidad garantizada. Los uso para competir y son espectaculares.",
    date: "2026-03-10",
    product: "Patines Competition Pro"
  }
];