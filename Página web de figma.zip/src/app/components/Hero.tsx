import { ArrowRight, Zap } from 'lucide-react';

export function Hero() {
  const scrollToProducts = () => {
    const element = document.getElementById('productos');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-slate-900 via-emerald-950 to-black">
      {/* Animated Background */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-20 left-20 w-72 h-72 bg-emerald-500 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-lime-500 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 grid lg:grid-cols-2 gap-12 items-center">
        {/* Text Content */}
        <div className="space-y-8 text-center lg:text-left">
          <div className="inline-flex items-center space-x-2 bg-emerald-600/20 border border-emerald-500/30 rounded-full px-4 py-2 backdrop-blur-sm">
            <Zap className="w-4 h-4 text-emerald-400" />
            <span className="text-emerald-300 text-sm">La mejor tienda de patines en línea</span>
          </div>

          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold leading-tight">
            <span className="bg-gradient-to-r from-white via-emerald-200 to-white bg-clip-text text-transparent">
              Patines en Línea
            </span>
            <br />
            <span className="bg-gradient-to-r from-emerald-400 via-lime-400 to-emerald-400 bg-clip-text text-transparent">
              para Cada Estilo
            </span>
          </h1>

          <p className="text-xl text-slate-300 max-w-2xl">
            Descubre nuestra selección de patines en línea profesionales: urbanos, fitness, velocidad y principiantes. 
            Calidad premium para todos los niveles.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
            <button
              onClick={scrollToProducts}
              className="group bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white px-8 py-4 rounded-xl flex items-center justify-center space-x-2 shadow-lg shadow-emerald-500/50 transition-all transform hover:scale-105"
            >
              <span className="text-lg">Ver Productos</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={scrollToProducts}
              className="bg-white/10 hover:bg-white/20 text-white border border-white/20 px-8 py-4 rounded-xl backdrop-blur-sm transition-all transform hover:scale-105"
            >
              <span className="text-lg">Explorar Categorías</span>
            </button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-6 pt-8 border-t border-slate-700">
            <div className="text-center lg:text-left">
              <div className="text-3xl font-bold text-white">200+</div>
              <div className="text-sm text-slate-400">Modelos</div>
            </div>
            <div className="text-center lg:text-left">
              <div className="text-3xl font-bold text-white">15k+</div>
              <div className="text-sm text-slate-400">Patinadores</div>
            </div>
            <div className="text-center lg:text-left">
              <div className="text-3xl font-bold text-white">4.9★</div>
              <div className="text-sm text-slate-400">Valoración</div>
            </div>
          </div>
        </div>

        {/* Hero Image */}
        <div className="relative">
          <div className="absolute inset-0 bg-gradient-to-r from-emerald-600 to-lime-600 rounded-3xl blur-2xl opacity-30"></div>
          <img
            src="https://images.unsplash.com/photo-1756888821859-64e8618cc1e6?w=800"
            alt="Patinaje en línea"
            className="relative rounded-3xl shadow-2xl w-full h-[500px] object-cover border border-white/10"
          />
          
          {/* Floating Badge */}
          <div className="absolute -bottom-6 -left-6 bg-gradient-to-r from-lime-500 to-emerald-600 text-black px-6 py-4 rounded-2xl shadow-xl">
            <div className="text-2xl font-bold">-25%</div>
            <div className="text-sm">En productos seleccionados</div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex items-start justify-center p-2">
          <div className="w-1 h-2 bg-white rounded-full"></div>
        </div>
      </div>
    </section>
  );
}