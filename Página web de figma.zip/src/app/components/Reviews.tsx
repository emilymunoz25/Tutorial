import { Star, Quote } from 'lucide-react';
import { reviews } from '../data/products';

export function Reviews() {
  return (
    <section className="py-20 bg-gradient-to-b from-black to-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-yellow-600/20 border border-yellow-500/30 rounded-full px-4 py-2 backdrop-blur-sm mb-4">
            <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
            <span className="text-yellow-300 text-sm">Opiniones Reales</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-white to-yellow-400 bg-clip-text text-transparent">
              Lo Que Dicen Nuestros Clientes
            </span>
          </h2>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto">
            Miles de patinadores confían en nosotros
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {reviews.map((review) => (
            <div
              key={review.id}
              className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-6 border border-slate-700 hover:border-yellow-500 transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:shadow-yellow-500/20"
            >
              {/* Quote Icon */}
              <div className="mb-4">
                <Quote className="w-8 h-8 text-yellow-400 opacity-50" />
              </div>

              {/* Rating */}
              <div className="flex items-center space-x-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${
                      i < review.rating
                        ? 'text-yellow-400 fill-yellow-400'
                        : 'text-slate-600'
                    }`}
                  />
                ))}
              </div>

              {/* Comment */}
              <p className="text-slate-300 mb-6 leading-relaxed">
                "{review.comment}"
              </p>

              {/* Author */}
              <div className="border-t border-slate-700 pt-4">
                <div className="font-semibold text-white mb-1">
                  {review.name}
                </div>
                <div className="text-slate-400 text-sm mb-2">
                  {review.product}
                </div>
                <div className="text-slate-500 text-xs">
                  {new Date(review.date).toLocaleDateString('es-ES', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Average Rating */}
        <div className="mt-16 text-center">
          <div className="inline-block bg-gradient-to-r from-yellow-600/20 to-orange-600/20 border border-yellow-500/30 rounded-2xl px-8 py-6 backdrop-blur-sm">
            <div className="flex items-center justify-center space-x-4">
              <div>
                <div className="text-5xl font-bold text-white">4.9</div>
                <div className="flex items-center justify-center space-x-1 mt-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                  ))}
                </div>
              </div>
              <div className="border-l border-slate-600 pl-6 text-left">
                <div className="text-slate-400 text-sm">Basado en</div>
                <div className="text-white text-xl font-bold">+2,500 opiniones</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
