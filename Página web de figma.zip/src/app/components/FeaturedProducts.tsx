import { ProductCard } from './ProductCard';
import { products } from '../data/products';

export function FeaturedProducts() {
  const featuredProducts = products.filter((p) => p.featured);

  return (
    <section id="productos" className="py-20 bg-gradient-to-b from-black to-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-emerald-600/20 border border-emerald-500/30 rounded-full px-4 py-2 backdrop-blur-sm mb-4">
            <span className="text-emerald-300 text-sm">Lo Más Popular</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-white to-emerald-400 bg-clip-text text-transparent">
              Productos Destacados
            </span>
          </h2>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto">
            Descubre nuestra selección de patines en línea más vendidos y mejor valorados por la comunidad
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        <div className="text-center mt-12">
          <button
            onClick={() => {
              const allProducts = document.getElementById('todas-categorias');
              if (allProducts) {
                allProducts.scrollIntoView({ behavior: 'smooth' });
              }
            }}
            className="bg-white/10 hover:bg-white/20 text-white border border-white/20 px-8 py-3 rounded-xl backdrop-blur-sm transition-all transform hover:scale-105"
          >
            Ver Todos los Productos
          </button>
        </div>
      </div>
    </section>
  );
}