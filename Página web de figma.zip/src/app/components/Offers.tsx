import { Clock, Percent, Flame } from 'lucide-react';
import { ProductCard } from './ProductCard';
import { products } from '../data/products';

export function Offers() {
  const offerProducts = products.filter((p) => p.discount);

  return (
    <section id="ofertas" className="py-20 bg-gradient-to-b from-black via-emerald-950/10 to-slate-900 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-emerald-500 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-lime-500 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-emerald-600/20 to-lime-600/20 border border-emerald-500/30 rounded-full px-4 py-2 backdrop-blur-sm mb-4">
            <Flame className="w-4 h-4 text-emerald-400" />
            <span className="text-emerald-300 text-sm font-semibold">¡Ofertas Limitadas!</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-emerald-400 via-lime-400 to-emerald-400 bg-clip-text text-transparent">
              Promociones Especiales
            </span>
          </h2>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto">
            Aprovecha descuentos increíbles en patines en línea de alta calidad
          </p>
        </div>

        {/* Offer Highlights */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="bg-gradient-to-br from-emerald-600/20 to-emerald-800/20 border border-emerald-500/30 rounded-2xl p-6 backdrop-blur-sm">
            <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-xl flex items-center justify-center mb-4">
              <Percent className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Hasta 25% OFF</h3>
            <p className="text-slate-300 text-sm">En productos seleccionados de alta gama</p>
          </div>

          <div className="bg-gradient-to-br from-lime-600/20 to-lime-800/20 border border-lime-500/30 rounded-2xl p-6 backdrop-blur-sm">
            <div className="w-12 h-12 bg-gradient-to-br from-lime-500 to-lime-600 rounded-xl flex items-center justify-center mb-4">
              <Clock className="w-6 h-6 text-black" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Tiempo Limitado</h3>
            <p className="text-slate-300 text-sm">Ofertas válidas hasta fin de mes</p>
          </div>

          <div className="bg-gradient-to-br from-teal-600/20 to-teal-800/20 border border-teal-500/30 rounded-2xl p-6 backdrop-blur-sm">
            <div className="w-12 h-12 bg-gradient-to-br from-teal-500 to-teal-600 rounded-xl flex items-center justify-center mb-4">
              <Flame className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Stock Limitado</h3>
            <p className="text-slate-300 text-sm">¡No te quedes sin el tuyo!</p>
          </div>
        </div>

        {/* Offer Products */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {offerProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  );
}