import { Navigation, Activity, Zap, Heart, ArrowRight } from 'lucide-react';
import { categories } from '../data/products';

const iconMap = {
  Navigation,
  Activity,
  Zap,
  Heart,
};

export function Categories() {
  return (
    <section id="categorias" className="py-20 bg-gradient-to-b from-slate-900 to-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-lime-600/20 border border-lime-500/30 rounded-full px-4 py-2 backdrop-blur-sm mb-4">
            <span className="text-lime-300 text-sm">Explora por Tipo</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-white to-lime-400 bg-clip-text text-transparent">
              Categorías de Patines
            </span>
          </h2>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto">
            Encuentra los patines en línea perfectos para tu nivel y estilo
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category) => {
            const Icon = iconMap[category.icon as keyof typeof iconMap];
            return (
              <div
                key={category.id}
                className="group relative overflow-hidden rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-105 cursor-pointer"
              >
                {/* Background Image */}
                <div className="absolute inset-0">
                  <img
                    src={category.image}
                    alt={category.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-transparent"></div>
                </div>

                {/* Content */}
                <div className="relative p-6 h-64 flex flex-col justify-end">
                  <div className="mb-4 w-12 h-12 bg-gradient-to-br from-emerald-500 to-lime-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2 group-hover:text-emerald-400 transition-colors">
                    {category.name}
                  </h3>
                  <p className="text-slate-300 text-sm mb-4">
                    {category.description}
                  </p>
                  <button className="flex items-center space-x-2 text-emerald-400 font-semibold group-hover:text-lime-400 transition-colors">
                    <span>Explorar</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}