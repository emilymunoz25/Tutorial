import { Link } from 'react-router';
import { ShoppingCart, Menu, X } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useState } from 'react';

export function Header() {
  const { getCartCount } = useCart();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const cartCount = getCartCount();

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-r from-slate-900 via-emerald-900 to-slate-900 shadow-xl">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2 group">
            <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-lime-500 rounded-lg flex items-center justify-center transform group-hover:scale-110 transition-transform">
              <span className="text-white text-xl">⚡</span>
            </div>
            <span className="text-white text-xl font-bold hidden sm:block">InlineZone</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-6">
            <button
              onClick={() => scrollToSection('productos')}
              className="text-white hover:text-emerald-400 transition-colors"
            >
              Productos
            </button>
            <button
              onClick={() => scrollToSection('categorias')}
              className="text-white hover:text-emerald-400 transition-colors"
            >
              Categorías
            </button>
            <button
              onClick={() => scrollToSection('ofertas')}
              className="text-white hover:text-emerald-400 transition-colors"
            >
              Ofertas
            </button>
            <button
              onClick={() => scrollToSection('contacto')}
              className="text-white hover:text-emerald-400 transition-colors"
            >
              Contacto
            </button>
          </div>

          {/* Cart & Mobile Menu */}
          <div className="flex items-center space-x-4">
            <Link
              to="/carrito"
              className="relative flex items-center space-x-2 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg transition-colors"
            >
              <ShoppingCart className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-lime-500 text-black text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
              <span className="hidden sm:inline">Carrito</span>
            </Link>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden text-white p-2"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 space-y-3 border-t border-slate-700">
            <button
              onClick={() => scrollToSection('productos')}
              className="block w-full text-left text-white hover:text-emerald-400 transition-colors py-2"
            >
              Productos
            </button>
            <button
              onClick={() => scrollToSection('categorias')}
              className="block w-full text-left text-white hover:text-emerald-400 transition-colors py-2"
            >
              Categorías
            </button>
            <button
              onClick={() => scrollToSection('ofertas')}
              className="block w-full text-left text-white hover:text-emerald-400 transition-colors py-2"
            >
              Ofertas
            </button>
            <button
              onClick={() => scrollToSection('contacto')}
              className="block w-full text-left text-white hover:text-emerald-400 transition-colors py-2"
            >
              Contacto
            </button>
          </div>
        )}
      </nav>
    </header>
  );
}