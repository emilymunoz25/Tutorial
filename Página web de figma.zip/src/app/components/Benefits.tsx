import { Truck, Shield, Award, Headphones } from 'lucide-react';

export function Benefits() {
  const benefits = [
    {
      icon: Truck,
      title: 'Envío Gratis',
      description: 'En compras superiores a $100. Entrega rápida y segura',
      color: 'from-emerald-500 to-emerald-600',
    },
    {
      icon: Shield,
      title: 'Garantía Extendida',
      description: 'Hasta 2 años en todos nuestros productos',
      color: 'from-green-500 to-green-600',
    },
    {
      icon: Award,
      title: 'Calidad Premium',
      description: 'Productos certificados de las mejores marcas',
      color: 'from-lime-500 to-lime-600',
    },
    {
      icon: Headphones,
      title: 'Atención 24/7',
      description: 'Soporte dedicado cuando lo necesites',
      color: 'from-teal-500 to-teal-600',
    },
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-slate-900 to-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-green-600/20 border border-green-500/30 rounded-full px-4 py-2 backdrop-blur-sm mb-4">
            <span className="text-green-300 text-sm">¿Por Qué Elegirnos?</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-white to-green-400 bg-clip-text text-transparent">
              Nuestros Beneficios
            </span>
          </h2>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto">
            Tu satisfacción y seguridad son nuestra prioridad
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <div
                key={index}
                className="group bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-8 border border-slate-700 hover:border-emerald-500 transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:shadow-emerald-500/20"
              >
                <div
                  className={`w-16 h-16 bg-gradient-to-br ${benefit.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-lg`}
                >
                  <Icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-emerald-400 transition-colors">
                  {benefit.title}
                </h3>
                <p className="text-slate-400 leading-relaxed">
                  {benefit.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Trust Indicators */}
        <div className="mt-16 bg-gradient-to-r from-slate-800/50 to-slate-900/50 border border-slate-700 rounded-2xl p-8 backdrop-blur-sm">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-3xl md:text-4xl font-bold text-white mb-2">99%</div>
              <div className="text-slate-400 text-sm">Satisfacción</div>
            </div>
            <div>
              <div className="text-3xl md:text-4xl font-bold text-white mb-2">15k+</div>
              <div className="text-slate-400 text-sm">Clientes Felices</div>
            </div>
            <div>
              <div className="text-3xl md:text-4xl font-bold text-white mb-2">24h</div>
              <div className="text-slate-400 text-sm">Respuesta</div>
            </div>
            <div>
              <div className="text-3xl md:text-4xl font-bold text-white mb-2">200+</div>
              <div className="text-slate-400 text-sm">Modelos</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}