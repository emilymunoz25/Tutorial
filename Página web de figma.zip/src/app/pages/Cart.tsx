import { Link } from 'react-router';
import { Minus, Plus, Trash2, ShoppingBag, ArrowLeft, CreditCard } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { toast } from 'sonner';

export function Cart() {
  const { cart, removeFromCart, updateQuantity, getCartTotal } = useCart();

  const handleCheckout = () => {
    toast.success('¡Procesando pago! En una implementación real, aquí se integraría con un procesador de pagos.', {
      duration: 4000,
    });
  };

  if (cart.length === 0) {
    return (
      <div className="min-h-screen bg-black">
        <Header />
        <main className="pt-24 pb-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center py-20">
              <div className="w-24 h-24 bg-gradient-to-br from-slate-800 to-slate-900 rounded-full flex items-center justify-center mx-auto mb-8">
                <ShoppingBag className="w-12 h-12 text-slate-400" />
              </div>
              <h2 className="text-3xl font-bold text-white mb-4">
                Tu carrito está vacío
              </h2>
              <p className="text-slate-400 mb-8 max-w-md mx-auto">
                Parece que aún no has agregado ningún producto. ¡Explora nuestra tienda y encuentra los patines perfectos!
              </p>
              <Link
                to="/"
                className="inline-flex items-center space-x-2 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white px-8 py-4 rounded-xl font-semibold shadow-lg shadow-emerald-500/30 transition-all transform hover:scale-105"
              >
                <ArrowLeft className="w-5 h-5" />
                <span>Volver a la Tienda</span>
              </Link>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      <Header />
      <main className="pt-24 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-12">
            <Link
              to="/"
              className="inline-flex items-center space-x-2 text-emerald-400 hover:text-emerald-300 transition-colors mb-6"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Volver a la tienda</span>
            </Link>
            <h1 className="text-4xl md:text-5xl font-bold">
              <span className="bg-gradient-to-r from-white to-emerald-400 bg-clip-text text-transparent">
                Tu Carrito
              </span>
            </h1>
            <p className="text-slate-400 mt-2">
              Tienes {cart.length} {cart.length === 1 ? 'producto' : 'productos'} en tu carrito
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              {cart.map((item) => (
                <div
                  key={item.id}
                  className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-6 border border-slate-700 hover:border-emerald-500 transition-all"
                >
                  <div className="flex flex-col sm:flex-row gap-6">
                    {/* Image */}
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full sm:w-32 h-32 object-cover rounded-xl"
                    />

                    {/* Details */}
                    <div className="flex-1 space-y-4">
                      <div>
                        <h3 className="text-xl font-bold text-white mb-2">
                          {item.name}
                        </h3>
                        <p className="text-slate-400 text-sm">
                          {item.description}
                        </p>
                      </div>

                      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                        {/* Quantity Controls */}
                        <div className="flex items-center space-x-3">
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="w-10 h-10 bg-slate-700 hover:bg-slate-600 rounded-lg flex items-center justify-center transition-colors"
                          >
                            <Minus className="w-4 h-4 text-white" />
                          </button>
                          <span className="text-white font-semibold w-12 text-center">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="w-10 h-10 bg-slate-700 hover:bg-slate-600 rounded-lg flex items-center justify-center transition-colors"
                          >
                            <Plus className="w-4 h-4 text-white" />
                          </button>
                        </div>

                        {/* Price */}
                        <div className="flex items-center justify-between sm:justify-end gap-4 w-full sm:w-auto">
                          <div className="text-right">
                            <div className="text-2xl font-bold text-white">
                              ${(item.price * item.quantity).toFixed(2)}
                            </div>
                            <div className="text-sm text-slate-400">
                              ${item.price.toFixed(2)} c/u
                            </div>
                          </div>

                          {/* Remove Button */}
                          <button
                            onClick={() => {
                              removeFromCart(item.id);
                              toast.success('Producto eliminado del carrito');
                            }}
                            className="w-10 h-10 bg-red-600/20 hover:bg-red-600 rounded-lg flex items-center justify-center transition-colors group"
                          >
                            <Trash2 className="w-5 h-5 text-red-400 group-hover:text-white" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-8 border border-slate-700 sticky top-24">
                <h2 className="text-2xl font-bold text-white mb-6">
                  Resumen del Pedido
                </h2>

                <div className="space-y-4 mb-6">
                  <div className="flex items-center justify-between text-slate-300">
                    <span>Subtotal</span>
                    <span className="font-semibold">${getCartTotal().toFixed(2)}</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-300">
                    <span>Envío</span>
                    <span className="font-semibold text-emerald-400">GRATIS</span>
                  </div>
                  <div className="border-t border-slate-700 pt-4">
                    <div className="flex items-center justify-between">
                      <span className="text-xl font-bold text-white">Total</span>
                      <span className="text-2xl font-bold text-white">
                        ${getCartTotal().toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleCheckout}
                  className="w-full bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white py-4 rounded-xl font-semibold flex items-center justify-center space-x-2 shadow-lg shadow-emerald-500/30 transition-all transform hover:scale-105 mb-4"
                >
                  <CreditCard className="w-5 h-5" />
                  <span>Proceder al Pago</span>
                </button>

                <Link
                  to="/"
                  className="block w-full text-center bg-white/10 hover:bg-white/20 text-white border border-white/20 py-3 rounded-xl backdrop-blur-sm transition-all"
                >
                  Seguir Comprando
                </Link>

                {/* Benefits */}
                <div className="mt-8 pt-8 border-t border-slate-700 space-y-3">
                  <div className="flex items-center space-x-3 text-sm text-slate-300">
                    <div className="w-6 h-6 bg-emerald-600 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-white text-xs">✓</span>
                    </div>
                    <span>Envío gratis en compras +$100</span>
                  </div>
                  <div className="flex items-center space-x-3 text-sm text-slate-300">
                    <div className="w-6 h-6 bg-emerald-600 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-white text-xs">✓</span>
                    </div>
                    <span>Garantía extendida 2 años</span>
                  </div>
                  <div className="flex items-center space-x-3 text-sm text-slate-300">
                    <div className="w-6 h-6 bg-emerald-600 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-white text-xs">✓</span>
                    </div>
                    <span>Devoluciones gratis 30 días</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}