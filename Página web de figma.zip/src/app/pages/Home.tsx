import { Header } from '../components/Header';
import { Hero } from '../components/Hero';
import { FeaturedProducts } from '../components/FeaturedProducts';
import { Categories } from '../components/Categories';
import { Offers } from '../components/Offers';
import { Benefits } from '../components/Benefits';
import { Reviews } from '../components/Reviews';
import { ContactForm } from '../components/ContactForm';
import { Footer } from '../components/Footer';

export function Home() {
  return (
    <div className="min-h-screen bg-black">
      <Header />
      <main>
        <Hero />
        <FeaturedProducts />
        <Categories />
        <Offers />
        <Benefits />
        <Reviews />
        <ContactForm />
      </main>
      <Footer />
    </div>
  );
}
