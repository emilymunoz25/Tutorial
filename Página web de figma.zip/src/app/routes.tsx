import { createBrowserRouter } from 'react-router';
import { Home } from './pages/Home';
import { Cart } from './pages/Cart';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Home,
  },
  {
    path: '/carrito',
    Component: Cart,
  },
]);
